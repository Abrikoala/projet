#!/bin/bash
docker build -t gridbot .
docker run -d --name gridbot gridbot
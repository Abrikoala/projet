# wallet loading and handling

# main script to coordinate the strategy

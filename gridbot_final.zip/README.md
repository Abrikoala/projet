# GridBot Final
Bot de trading crypto avec IA, stratégie dynamique, optimisation automatique, et exécution perp sur Solana.
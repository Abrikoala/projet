# helper functions and logger

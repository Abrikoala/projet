# trade execution logic with AI filter

# logic for grid management

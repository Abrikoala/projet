# XGBoost predictor with full feature set

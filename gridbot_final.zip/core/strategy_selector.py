# strategy selection logic based on market context

# capital protection logic

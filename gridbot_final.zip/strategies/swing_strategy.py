# execute swing strategy

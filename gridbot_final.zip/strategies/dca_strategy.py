# execute DCA strategy

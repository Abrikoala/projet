# execute grid strategy

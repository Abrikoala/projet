from flask import Flask, render_template, request, send_file
import subprocess
from fpdf import FPDF
import requests
import os
from datetime import datetime

app = Flask(__name__)

def run_nmap(target):
    result = subprocess.run(['nmap', '-sV', target], capture_output=True, text=True)
    return result.stdout

def get_headers(url):
    try:
        response = requests.get(url, timeout=5)
        return response.headers
    except:
        return {}

def generate_pdf_report(target, nmap_result, headers):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    pdf.cell(200, 10, f"Rapport d'audit de : {target}", ln=True)

    pdf.ln(10)
    pdf.cell(200, 10, "Résultats Nmap :", ln=True)
    pdf.multi_cell(0, 10, nmap_result)

    pdf.ln(10)
    pdf.cell(200, 10, "Headers HTTP :", ln=True)
    for k, v in headers.items():
        pdf.cell(200, 10, f"{k}: {v}", ln=True)

    filename = f"/tmp/rapport_audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf.output(filename)
    return filename

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        target = request.form["target"]
        nmap_result = run_nmap(target)
        url = "http://" + target if not target.startswith("http") else target
        headers = get_headers(url)
        pdf_path = generate_pdf_report(target, nmap_result, headers)
        return send_file(pdf_path, as_attachment=True)

    return render_template("form.html")

if __name__ == "__main__":
    app.run(debug=True)
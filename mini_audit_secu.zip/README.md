# Mini Audit de Sécurité Web – Interface Flask

## Description
Audit de base d'un site ou IP via interface web Flask :
- Scan Nmap
- Analyse des headers HTTP
- Rapport PDF généré automatiquement

## Installation
```bash
pip install -r requirements.txt
```

## Lancement
```bash
python app.py
```

## Accès
Puis ouvrir `http://127.0.0.1:5000` dans votre navigateur.
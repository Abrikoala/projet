from flask import Flask, render_template, request, send_file
from fpdf import FPDF
import os
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def form():
    return """
    <form action="/generate" method="post">
        Nom : <input type="text" name="name"><br>
        Message : <input type="text" name="message"><br>
        <input type="submit" value="Générer PDF">
    </form>
    """

@app.route('/generate', methods=['POST'])
def generate():
    name = request.form['name']
    message = request.form['message']
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt=f"Nom : {name}", ln=True)
    pdf.cell(200, 10, txt=f"Message : {message}", ln=True)

    output_path = f"/tmp/generated_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf.output(output_path)

    return send_file(output_path, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)
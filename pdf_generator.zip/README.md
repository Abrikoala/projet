# Générateur de PDF personnalisé

## Description
Ce projet est une application Flask simple qui permet à l'utilisateur de remplir un formulaire web et de recevoir un PDF personnalisé en retour.

## Utilisation
```bash
pip install -r requirements.txt
python app.py
```
Accédez ensuite à `http://127.0.0.1:5000` dans votre navigateur.
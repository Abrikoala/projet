import subprocess
import os

def extract_clip(input_file, start_time, duration, output_file):
    command = [
        "ffmpeg",
        "-ss", str(start_time),
        "-i", input_file,
        "-t", str(duration),
        "-c", "copy",
        output_file
    ]
    subprocess.run(command)
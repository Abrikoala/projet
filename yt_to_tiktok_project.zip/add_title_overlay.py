from moviepy.editor import VideoFileClip, TextClip, CompositeVideoClip

def add_title_overlay(video_path, title_text, output_path):
    clip = VideoFileClip(video_path)
    txt_clip = TextClip(title_text, fontsize=24, color='white')
    txt_clip = txt_clip.set_position(("left", "bottom")).set_duration(clip.duration)
    video = CompositeVideoClip([clip, txt_clip])
    video.write_videofile(output_path, codec="libx264")
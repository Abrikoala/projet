import whisper

def generate_subtitles(input_path, model_size='base'):
    model = whisper.load_model(model_size)
    result = model.transcribe(input_path)
    with open(input_path + '.srt', 'w', encoding='utf-8') as f:
        for i, segment in enumerate(result['segments']):
            f.write(f"{i+1}\n")
            f.write(f"{segment['start']} --> {segment['end']}\n")
            f.write(f"{segment['text']}\n\n")
from download_video import download_video
from extract_clips import extract_clip
from generate_subtitles import generate_subtitles
from add_title_overlay import add_title_overlay
import os

# Example parameters
video_url = "https://www.youtube.com/watch?v=example"
download_video(video_url)

# Example processing (manual paths for now)
input_video = "downloads/example.mp4"
clip_path = "output_clip.mp4"
final_path = "final_video.mp4"

extract_clip(input_video, start_time=30, duration=60, output_file=clip_path)
generate_subtitles(clip_path)
add_title_overlay(clip_path, "Titre automatique généré", final_path)